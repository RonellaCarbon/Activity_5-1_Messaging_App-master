package com.raywenderlich.RayChat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
